
cp ../transistors_as_subckts.sp .
cp ../bitline_puf_16x1_ckt.sp .
cp ../bitline_puf_16x1_pv.sp .
cp ../bitline_puf_16x1_pv.data .


create_pv_instances_spice.pl \
     --dir_instances    instances \
     --fname_instances  instances/instances.data \
     --num_instances    10000 \
     --fname_pv_data    bitline_puf_16x1_pv.data \
     --fname_pv_spice   bitline_puf_16x1_pv.sp \


create_challenges_spice.pl \
    --num_challenges    10000 \
    --num_cells         16 \
    --dir_challenges    challenges \
    --fname_challenges  challenges/challenges.data \
    --w_min             0.49 \
    --w_max             0.51 \

measure_responses_hd.pl \
    --fname_challenges  challenges/challenges.data \
    --fname_instances   instances/instances.data \
    --spice_file        bitline_puf_16x1_ckt.sp \
    --num_challenges    200 \
    --num_pufs          5 \
    --num_columns       32 \
    --num_repeats       6 \
    --fname_responses  "responses.data"

create_hd_histogram_dat.pl \
    --fname_responses  "responses.data" \
    --fname_dat        "hd_plot.dat" \
    --bin_max          32


gnuplot hd_plot.gp
epstopdf hd_plot.eps
rm hd_plot.eps

