#!/usr/bin/env perl

use Carp;
use strict;
use Data::Dumper;
$Data::Dumper::Terse = 1;
use Math::VecStat qw(max min maxabs minabs sum average);
use Getopt::Long;

require "spuf_utils.pl";


system('cp ../transistors_as_subckts.sp .');
system('cp ../bitline_puf_16x1_ckt.sp .');
system('cp ../bitline_puf_16x1_pv.sp .');
system('cp ../bitline_puf_16x1_pv.data .');

system('create_pv_instances_spice.pl \
     --dir_instances    instances \
     --fname_instances  instances/instances.data \
     --num_instances    40 \
     --fname_pv_data    bitline_puf_16x1_pv.data \
     --fname_pv_spice   bitline_puf_16x1_pv.sp ');

my $instances = eval(readFileScalar('instances/instances.data'));


my $Num_Trials = 30;

foreach (0,1) {
     my $Fname_Plot = "";
     my $challenges = "";

     if ($_ == 0) {
	  # run many instances with a single challenge that reads single cell
 	  $Fname_Plot = "bl_discharge_plot_single";
	  my @challenge = (0,2,3,2, 3,2,3,2, 3,2,3,2, 3,2,3,2);
	  my $challenge_file = "challenge.sp";
	  create_challenge_spice({   "CHALLENGE"      => \@challenge,
				     "CHALLENGE_FILE" => $challenge_file,
				     "NUM_CELLS"      => 16 });
	  $challenges = ['challenge.sp']; 

     } else {
	  # run many instances with different unbiased challenges
	  $Fname_Plot = "bl_discharge_plot_multiple";
	  system('create_challenges_spice.pl \
    --num_challenges    40 \
    --num_cells         16 \
    --dir_challenges    challenges_unbiased \
    --fname_challenges  challenges_unbiased/challenges.data \
    --w_min             0.49 \
    --w_max             0.51 ');
	  $challenges = eval(readFileScalar('challenges_unbiased/challenges.data')); 

     }
     
 

     my @dats = ();
     foreach (0..$Num_Trials-1) {
	  my $c = @$challenges->[int(rand($#$challenges))];
	  my $i = @$instances->[int(rand($#$instances))];
	  system ('ngspice -b -o ngspice.out bitline_puf_16x1_ckt.sp '.$c.' '.$i.' other_stuff.sp');
	  my $fname = "tran.".$_.".dat";
	  convert_spice_transient_output_to_dat("ngspice.out", $fname);
	  push (@dats, $fname);
     }



     # plot the waveforms for all trials of read or unbiased challenges

     open GP, "> $Fname_Plot.gp" or die "Can't open : $!";
     print GP  'set terminal postscript eps enhanced color "Times-Roman" 20; '."\n";
     print GP  'set size 0.7,0.5;'."\n";
     print GP  'set output "'.$Fname_Plot.'.eps"'."\n";
     print GP  'set xlabel "Time [ns]"'."\n";
     print GP  'set ylabel "Voltage" offset 1.7'."\n";
     print GP  'set key rmargin;'."\n";
     print GP  "set key spacing 1.4;\n";
     print GP  'set grid xtics ytics;'."\n";
     print GP  'set xtics( "0" 0, "0.5" 5e-10, "1" 1e-9, "1.5" 1.5e-9, "2" 2e-9, "2.5" 2.5e-9, "3" 3e-9);'."\n";
     print GP  'set yrange [0:1.2];'."\n";
     print GP  'set ytics(0,0.4,0.8,1.2);'."\n";

     my $lw = 4;
     my $lw2 = 15;

     my @lines = ();
     foreach (0..$#dats) {
	  my $d = $dats[$_];
	  if ($_ == 0) {
	       push(@lines, '     "'.$d.'" using 2:5 w l lw '.$lw2.' lt 2 lc 5 t "PRE" ');
	       push(@lines, '     "'.$d.'" using 2:7 w l lw '.$lw2.' lt 4 lc 4 t "WL" ');
	       push(@lines, '     "'.$d.'" using 2:6 w l lw '.$lw2.' lt 3 lc 8 t "RE" ');
	       push(@lines, '     "'.$d.'" using 2:4 w l lw '.$lw.' lt 1 lc 3 t "BL" ');
	       push(@lines, '     "'.$d.'" using 2:3 w l lw '.$lw.' lt 1 lc 2 t "BLB" ');
	  }
	  push(@lines, '     "'.$d.'" using 2:4 w l lw '.$lw.' lt 1 lc 3 notitle');
	  push(@lines, '     "'.$d.'" using 2:3 w l lw '.$lw.' lt 1 lc 2 notitle');
     }
     print GP  "plot ".join(", \\\n", @lines).";\n";

     system("gnuplot ".$Fname_Plot.".gp");
     system("epstopdf ".$Fname_Plot.".eps");
}
exit(0);



