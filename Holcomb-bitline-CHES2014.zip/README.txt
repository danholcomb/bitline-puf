
This directory contains all of the code required to run the experiments for following paper:

@inproceedings{holcomb:ches2014bitline,
author = {Holcomb, Daniel E and Fu, Kevin},
title = {{Bitline PUF: Building Native Challenge-Response PUF Capability into Any SRAM}},
booktitle = {CHES'14: Proceedings of the 16th Workshop on Cryptographic Hardware and Embedded Systems},
year = {2014},
publisher = { Springer-Verlag},
month = sept
}


In order to run the experiments, you will need the following (free) software:
(1) NGSPICE (only tested on Rev 25)
(2) svm-light (if running the svm attacks)
(3) gnuplot


Here is how to run the experiments:
Make sure the "/scripts" directory is on your perl path (e.g. set PERL5LIB appropriately).

The script to generate each plot in the paper is within its own directory. These directories are named run_*

Some of these directories have a run.sh script in them. For these directories, you can do "make clean" to clean up, and do "nohup ./run.sh" to start the (long) experiment.

Other directories just have a Makefile and no run.sh. For these directories, just do "make"

You can email me questions at danholcomb@umich.edu or find me on the web.
