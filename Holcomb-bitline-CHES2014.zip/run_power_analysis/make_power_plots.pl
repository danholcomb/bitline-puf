#!/usr/bin/env perl

use Carp;
use strict;
use Data::Dumper;
$Data::Dumper::Terse = 1;
use Math::VecStat qw(max min maxabs minabs sum average);
use Getopt::Long;

require "spuf_utils.pl";

my $Num_Cells = 16;
my $Num_Challenges = 100; #how many for each challenge weight
my $Fname_Spice = 'bitline_puf_16x1_ckt.sp';

system('cp ../transistors_as_subckts.sp .');
system('cp ../bitline_puf_16x1_ckt.sp .');
system('cp ../bitline_puf_16x1_pv.sp .');
system('cp ../bitline_puf_16x1_pv.data .');
system('create_pv_instances_spice.pl \
             --dir_instances    instances \
             --fname_instances  instances/instances.data \
             --num_instances    200 \
             --fname_pv_data    bitline_puf_16x1_pv.data \
             --fname_pv_spice   bitline_puf_16x1_pv.sp \
             --seed 1');
my $instances = eval(readFileScalar('instances/instances.data'));
my $i = @$instances->[int(rand($#$instances))];


# create the data for the two transient plots showing current & voltage vs time
my @challenge = (0,3,2,3,2,3,2,3 ,2,3,2,3,2,3,2,3);
my $challenge_file = "challenge.sp";
create_challenge_spice({   "CHALLENGE"      => \@challenge,
			   "CHALLENGE_FILE" => $challenge_file,
			   "NUM_CELLS"      => $Num_Cells });
system ('ngspice -b -o ngspice.out '.$Fname_Spice.' '.$challenge_file.' '.$i.' other_stuff.sp');
convert_spice_transient_output_to_dat("ngspice.out", "tran0.dat");

my @challenge = (0,1,2,3,2,3,2,3 ,2,3,2,3,2,3,2,3);
my $challenge_file = "challenge.sp";
create_challenge_spice({   "CHALLENGE"      => \@challenge,
			   "CHALLENGE_FILE" => $challenge_file,
			   "NUM_CELLS"      => $Num_Cells });
system ('ngspice -b -o ngspice.out '.$Fname_Spice.' '.$challenge_file.' '.$i.' other_stuff.sp');
convert_spice_transient_output_to_dat("ngspice.out", "tran1.dat");


my @challenge = (0,1,0,1,0,1,0,1 ,2,3,2,3,2,3,2,3);
my $challenge_file = "challenge.sp";
create_challenge_spice({   "CHALLENGE"      => \@challenge,
			   "CHALLENGE_FILE" => $challenge_file,
			   "NUM_CELLS"      => $Num_Cells });
system ('ngspice -b -o ngspice.out '.$Fname_Spice.' '.$challenge_file.' '.$i.' other_stuff.sp');
convert_spice_transient_output_to_dat("ngspice.out", "tran2.dat");

exit(0);


# the 4 things stored for each spice sim:
use constant W_MIN       => 0;
use constant W_MAX       => 1;
use constant N_MIN       => 2;
use constant N_MAX       => 3;
my $exp = [ 
	   [ 0,    0,    1, 1]
	   ,[0.49, 0.51, 2, 2]
	   ,[0.49, 0.51, 4, 4]
	   ,[0.49, 0.51, 6, 6]
	   ,[0.49, 0.51, 8, 8]
	   ,[0.49, 0.51, 10, 10]
	   ,[0.49, 0.51, 12, 12]
	   ,[0.49, 0.51, 14, 14]
	   ,[0.49, 0.51, 16, 16]
	  ];


# measure the avg power of unbiased challenges with 1v1, 2v2, 3v3
my $dat = "";
foreach my $n (0..$#$exp) {
     my $e = $exp->[$n];

     system(' create_challenges_spice.pl \
                 --num_challenges    '.$Num_Challenges.' \
                 --num_cells         16 \
                 --dir_challenges    challenges_unbiased'.$n.' \
                 --fname_challenges  challenges_unbiased'.$n.'/challenges.data \
                 --w_min             '.$e->[W_MIN].' \
                 --w_max             '.$e->[W_MAX].' \
                 --n_min             '.$e->[N_MIN].' \
                 --n_max             '.$e->[N_MAX].' ;');
     my $challenges = eval(readFileScalar('challenges_unbiased'.$n.'/challenges.data')); 
     my @powers = ();
     foreach my $c (@$challenges) { 
	  my $i = @$instances->[int(rand($#$instances))];
	  system ('ngspice -b -o ngspice.out '.$Fname_Spice.' '.$c.' '.$i.' other_stuff.sp');
	  my $power = read_power_from_spice_output("ngspice.out");
	  push(@powers,$power);
     }

     print Dumper(@powers);
     my $std  = stdev(@powers);
     my $pmax = max(@powers);
     my $pmin = min(@powers);
     my $pavg = average(@powers);

     print Dumper($std,$pmax,$pmin,$pavg);
     
     my $line_result = sprintf("%2i, %2i, %+1.4e, %+1.4e, %+1.4e, %+1.4e\n",$n,$e->[N_MIN],$std,$pmin,$pavg,$pmax);
     if ($n == 0) {
	  writeFile("power_sweep_baseline.dat", $line_result);
     } else {
	  $dat .= $line_result;
     }
}

writeFile("power_sweep.dat", $dat);
exit(0);




sub stdev{
        my @data = @_;
        if(@data == 1){
                return 0;
        }
        my $average = average(@data);
        my $sqtotal = 0;
        foreach(@data) {
                $sqtotal += ($average-$_) ** 2;
        }
        my $std = ($sqtotal / (@data-1)) ** 0.5;
        return $std;
}



sub read_power_from_spice_output {
     my $fname = shift;
    my $text = readFileScalar($fname);
     if ($text =~ /.*iavg\s+=\s+([\d\-\+e\.]+).*/gm) {
	  print "power = $1\n";
	  return 1.2 * $1;
     } else {
	  croak;
     }
}
