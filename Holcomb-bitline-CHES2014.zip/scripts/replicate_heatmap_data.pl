#!/usr/bin/env perl

use Carp;
use strict;
use Data::Dumper;
$Data::Dumper::Terse = 1;
use Math::VecStat qw(max min maxabs minabs sum average);
use Getopt::Long;

require "spuf_utils.pl";

my $Fname = $ARGV[0]; 
my $Num_Replications = $ARGV[1];

open FIN, "< $Fname" or die "Can't open";
my @f = <FIN>;
close FIN;
my $text = "@f";
writeFile($Fname.".before_replication",$text);


my @lines = split(/[\n]+/,$text);
open FOUT, "> $Fname" or die "Can't open $Fname : $!";
foreach my $line (@lines) {
     $line =~ s/^\s+//;
     $line =~ s/\s+$//;
     my @line_data = split(/\s+/, $line);

     #create a new line that duplicates the data N times.
     my @line_data2 = ();
     foreach my $d (@line_data) {
	  push (@line_data2,$d) foreach (1..$Num_Replications);
     }
     my $line2 = join(" ",@line_data2)."\n";
     
     #print line N times to file
     print FOUT "$line2" foreach (1..$Num_Replications);
}

close FOUT;
exit;
