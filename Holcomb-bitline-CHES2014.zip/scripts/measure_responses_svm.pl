#!/usr/bin/env perl

use Carp;
use strict;
use Data::Dumper;
$Data::Dumper::Terse = 1;
use Math::VecStat qw(max min maxabs minabs sum average);
use Getopt::Long;

require "spuf_utils.pl";

my $Fname_Challenges  = "challenges.data"; 
my $Fname_Instances   = "instances.data"; 
my $Spice_File        = "spuf4_ckt.sp";
my $Fname_Data        = "exp.hd.data";
my $Num_Challenges    = 0; 
#my $Num_Instances     = 0; 

srand(1);

GetOptions ( 
	    "fname_instances=s"   => \$Fname_Instances,     
	    "fname_challenges=s"  => \$Fname_Challenges,
	    "num_challenges=i"    => \$Num_Challenges,
	    "spice_file=s"        => \$Spice_File,
#	    "num_instances=i"     => \$Num_Instances,
	    "fname_responses=s"   => \$Fname_Data,
	   ); 


measure_responses_svm({ 
		      "FNAME_CHALLENGES"  => $Fname_Challenges,
		      "SPICE_FILE"        => $Spice_File,
		      "FNAME_INSTANCES"   => $Fname_Instances,
		      "NUM_CHALLENGES"    => $Num_Challenges,   
#		       "NUM_INSTANCES"     => $Num_Instances,   
		      "FNAME_DATA"        => $Fname_Data,
		     });


sub measure_responses_svm {
     my ($args) = @_;
     my $fname_challenges    = $args->{"FNAME_CHALLENGES"};
     my $fname_instances     = $args->{"FNAME_INSTANCES"}; 
     my $spice_file          = $args->{"SPICE_FILE"};
     my $fname_data          = $args->{"FNAME_DATA"};

     my $num_challenges      = $args->{"NUM_CHALLENGES"}; 
     #my $num_instances       = $args->{"NUM_INSTANCES"}; 
     
     print ("-"x80,"\n");
     print ("$0: measure_responses_svm\n");
     print ("args: \n ".Dumper($args)."\n");
     print ("-"x80,"\n");
          
     my $challenges = eval(readFileScalar($fname_challenges));
     my $instances  = eval(readFileScalar($fname_instances));
 
     my $responses = ();
     #my $num_instances = ;
     foreach my $idx_instance (0.. $#$instances) {
     	  my $instance = $instances->[$idx_instance];
	  print "TIME: measure_hds: starting instance ".($idx_instance+1)." at ".localtime."\n";

	  foreach my $idx_challenge (0..$num_challenges-1) {
	       my $challenge = $challenges->[int(rand($#$challenges))];
	       print_spice_stats();
	       my $resp = get_column_response($spice_file, $instance, $challenge);
	       push(@$responses, [$idx_instance, $instance, $challenge, $resp]);
	  }
	  writeFile($fname_data.".inprogress", Dumper($responses));
     }
     print_spice_stats();
     writeFile($fname_data, Dumper($responses));
     return;
}

