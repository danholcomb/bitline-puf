#!/usr/bin/env perl

use Carp;
use strict;

use Data::Dumper;
$Data::Dumper::Terse = 1;
use Math::VecStat qw(max min maxabs minabs sum average);
use Getopt::Long;

require "spuf_utils.pl";


my $Fname_Results       = ""; # the file with the SPICE simulation results
my $Fname_Dat           = ""; # where to output the dat
my $Bin_Size  = 1;
my $Bin_Max = 20;

GetOptions (   
	    "fname_responses=s"    => \$Fname_Results,     
	    "fname_dat=s"          => \$Fname_Dat,
	    "bin_size=i"           => \$Bin_Size,
	    "bin_max=i"            => \$Bin_Max
	   ); 


print ("\n\n","-"x80,"\n");
printf ("fname_results         = %s \n",$Fname_Results);
printf ("fname_dat             = %s \n",$Fname_Dat);
print ("-"x80,"\n");


my @bin_boundaries = map {$Bin_Size * $_} (0..($Bin_Max/$Bin_Size));

my $dat = convert_hd_data("$Fname_Results");
my $hd_within  = $dat->{"HD_WITHIN"}; 
my $hd_between = $dat->{"HD_BETWEEN"};

my $avg_within = average($hd_within);
my $avg_between = average($hd_between);
print "avg hd within = $avg_within   ber = ".(100*$avg_within)."\n";
print "avg hd between = $avg_between  ber = ".(100*$avg_between)."\n";

my @hist_within = create_histogram_using_bins({   "VALS"           => $hd_within,
						  "BIN_BOUNDARIES" => \@bin_boundaries });


my @hist_between = create_histogram_using_bins({  "VALS"           => $hd_between,
						  "BIN_BOUNDARIES" => \@bin_boundaries });

(@hist_within == @hist_between) or croak;

my $dat = "";
foreach my $i (0..$#hist_within) {
     my $bin_name = ($hist_within[$i]->[0]->[0]%2) ? "":sprintf("%i", $hist_within[$i]->[0]->[0]);
     $dat .= sprintf("\"%s\", %f, %f\n",$bin_name, $hist_within[$i]->[1], $hist_between[$i]->[1]);
}
writeFile($Fname_Dat,$dat);

exit(0);






sub convert_hd_data {
     my $fname = shift;
     my $dat = eval(readFileScalar($fname));

     my $max_challenge = $#{$dat};

     print "$0 \n number of challenges = ".($max_challenge+1)."\n";
     my @hd_within = ();
     foreach my $idx_challenge (0..$max_challenge) {

	  my $max_puf = $#{$dat->[$idx_challenge]};
     	  foreach my $idx_instance (0..$max_puf) {

	       my $max_repeats = $#{$dat->[$idx_challenge]->[$idx_instance]};
	       
     	       foreach (unique_pairs([0..$max_repeats])) {
     	  	    my $i = $_ -> [0];
     	  	    my $j = $_ -> [1];
     	  	    my $r0 = $dat->[$idx_challenge]->[$idx_instance]->[$i];
     	  	    my $r1 = $dat->[$idx_challenge]->[$idx_instance]->[$j];
     	  	    my $hd = compute_hd($r0, $r1);
     	  	    push (@hd_within, $hd);
     	       }
     	  }
     }





     my @hd_between = ();
     my $max_challenge = $#{$dat};

     foreach my $idx_challenge (0..$max_challenge) {

	  my $max_puf = $#{$dat->[$idx_challenge]};

     	  foreach (unique_pairs([0..$max_puf])) {
     	       my $idx_instance0 = $_ -> [0];
     	       my $idx_instance1 = $_ -> [1];

	       my $max_repeats = $#{$dat->[$idx_challenge]->[$idx_instance0]};
	       my $max_repeats2 = $#{$dat->[$idx_challenge]->[$idx_instance1]};
	       croak unless ($max_repeats == $max_repeats2);
	       
     	       foreach (all_pairs([0..$max_repeats])) {
     		    my $i = $_ -> [0];
     		    my $j = $_ -> [1];

     		    my $r0 = $dat->[$idx_challenge]->[$idx_instance0]->[$i];
     		    my $r1 = $dat->[$idx_challenge]->[$idx_instance1]->[$j];
     		    my $hd = compute_hd($r0,$r1);
     		    if ($hd == 0) {
     			 print Dumper($r0);
     			 print Dumper($r1);
     			 print Dumper($idx_instance0);
     			 print Dumper($idx_instance1);
     		    }
     		    push (@hd_between, $hd);
     	       }
     	  }
     }


     my $dat = { "HD_WITHIN"  => \@hd_within,
     		 "HD_BETWEEN" => \@hd_between  };
     return $dat;
}
