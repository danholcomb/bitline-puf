#!/usr/bin/env perl

use Carp;
use strict;
use Data::Dumper;
$Data::Dumper::Terse = 1;
use Math::VecStat qw(max min maxabs minabs sum average);
use Getopt::Long;

require "spuf_utils.pl";


my $Fname_Challenges  = "challenges.data"; 
my $Spice_File        = "spuf4_ckt.sp";
my $Fname_Instances   = "instances.data"; 
my $Num_Trials        = 2;	
my $Fname_Data        = "exp.hd.data";
my $Parameter        = "x";
my @Parameter_Values  = ();

GetOptions ( 
	    "fname_challenges=s"  => \$Fname_Challenges,
	    "fname_instances=s"   => \$Fname_Instances,     
	    "spice_file=s"        => \$Spice_File,
	    "num_trials=i"        => \$Num_Trials,
	    "parameter=s"         => \$Parameter,
	    "parameter_value=f"   => \@Parameter_Values,
	    "fname_data=s"        => \$Fname_Data,
	   ); 

$Parameter =~ /(voltage|temperature)/ or croak;

measure_ber_vs_x({     "FNAME_CHALLENGES"  => $Fname_Challenges,
		       "SPICE_FILE"        => $Spice_File,
		       "FNAME_INSTANCES"   => $Fname_Instances,
		       "NUM_TRIALS"        => $Num_Trials,   
		       "PARAMETER_VALUES"  => \@Parameter_Values,
		       "PARAMETER"         => $Parameter,
		       "FNAME_DATA"        => $Fname_Data,
		 });


# the 4 values retained from each spice sim result:
use constant RESULT_IDX_TRIAL       => 0;
use constant RESULT_IDX_SWEEPVALUE  => 1;
use constant RESULT_SWEEPVALUE      => 2;
use constant RESULT_RESPONSE        => 3;


sub measure_ber_vs_x {
     my ($args) = @_;
     my $fname_challenges    = $args->{"FNAME_CHALLENGES"};
     my $fname_instances     = $args->{"FNAME_INSTANCES"}; 
     my $spice_file          = $args->{"SPICE_FILE"};
     my $fname_data          = $args->{"FNAME_DATA"};
     my $num_trials          = $args->{"NUM_TRIALS"};

     my $parameter           = $args->{"PARAMETER"};
     my @values              = @{$args->{"PARAMETER_VALUES"}};

     print ("-"x80,"\n");
     print ("$0: measure_ber_vs_x\n");
     print ("args: \n ".Dumper($args)."\n");
     print ("-"x80,"\n");
     
     my $c1 = eval(readFileScalar($fname_challenges));
     my $i1 = eval(readFileScalar($fname_instances));
 
     my $sim_results = ();
     foreach my $idx_trial (0..$num_trials-1) {
     	  my $chal = $c1->[int(rand($#$c1))];
     	  my $inst = $i1->[int(rand($#$i1))];

     	  print "TIME: measure_ber: starting trial ".($idx_trial+1)."/".$num_trials." at ".localtime."\n";
	  print_spice_stats();
	  foreach my $idx_value (0..$#values) {
	       my $value = $values[$idx_value];

	       #customize spice file to add parameter value:
	       my $spice_text = readFileScalar($spice_file);
	       if ($parameter eq "temperature") {
		    $spice_text = "\n.temp $value\n".$spice_text;
	       } elsif ($parameter eq "voltage") {
		    croak unless ($spice_text =~ s/\.param\s+vp\s+=\s+[\d\.]+v*/.param vp = $value/);
	       } else { croak;}

	       my $spice_file2 = "sweep__".$spice_file;
	       writeFile($spice_file2, $spice_text); 
	       
	       my $resp = get_column_response($spice_file2,$inst,$chal);

	       my $result = ();
	       $result->[RESULT_IDX_TRIAL]      = $idx_trial;
	       $result->[RESULT_IDX_SWEEPVALUE] = $idx_value;
	       $result->[RESULT_SWEEPVALUE]     = $value;
	       $result->[RESULT_RESPONSE]       = $resp;

	       push(@{$sim_results}, $result); 
	  }

	  writeFile($fname_data.'.inprogress', create_dat($sim_results));
     }
     
     print_spice_stats();
     print Dumper($sim_results);
     writeFile($fname_data, create_dat($sim_results));
     return;
}





# take in raw data, produce the ber statistics
sub create_dat {
     my $sim_results = shift;
     my $baseline = [grep {$_->[RESULT_IDX_SWEEPVALUE] == 0} @$sim_results]; 
     my $sweep    = [grep {$_->[RESULT_IDX_SWEEPVALUE] != 0} @$sim_results]; 
			      
     #create results in hash using appropriate comparison pairs
     my $results = ();
     foreach my $r1 (@$baseline) {
	  foreach my $r2 (@$sweep) {
	       #same crp, comparing base value against sweep value
	       if ($r1->[RESULT_IDX_TRIAL] == $r2->[RESULT_IDX_TRIAL])  {
		    my $v1 = $r1->[RESULT_SWEEPVALUE];
		    my $v2 = $r2->[RESULT_SWEEPVALUE];
		    $results->{$v1."_vs_".$v2} = [$v1,$v2,0,0] unless exists $results->{$v1."_vs_".$v2};
		    $results->{$v1."_vs_".$v2}->[2+($r1->[RESULT_RESPONSE] xor $r2->[RESULT_RESPONSE])]++;
	       }
	  }
     }
     

     #get rid of the keys and just return the data
     my @rlist = map {$results->{$_}} (keys %$results);

     my $dat_out = "";
     foreach my $d (sort {$a->[1] <=> $b->[1]} @rlist) {
     	  my $ber = $d->[3] / ($d->[2] + $d->[3]); 
     	  $dat_out .= sprintf ("%4s, %4s, %6i, %6i, %1.6f\n",$d->[0], $d->[1], $d->[2], $d->[3], $ber); 
     }
     
     return $dat_out;
}


