
use Data::Dumper;
$Data::Dumper::Terse = 1;
use Math::BaseCnv;
use Math::VecStat qw(max min maxabs minabs sum average);
use Getopt::Long;
use Storable 'dclone';
use List::Util 'shuffle';
use Carp;




my $Spice_Stats = { "NUM_AMBIGIOUS_RESULTS" => 0, 
		    "NUM_RUNS"              => 0,
		    "NUM_FAILURES"          => 0  };

sub print_spice_stats { print "\n at: ".localtime."\nSpice_Stats\n".Dumper($Spice_Stats)."\n";}


sub create_histogram_using_bins {
     my ($args) = @_;
     my @xvals      = @{$args->{"BIN_BOUNDARIES"}};
     my @vals       = @{$args->{"VALS"}};


     my $cnt = ();
     $cnt->{$_} = 0 foreach (@xvals);
     foreach my $v (@vals) {
	  if ($v < $xvals[1]) {
	       $cnt->{$xvals[0]}++;
	  } elsif ($v > $xvals[-2]) {
	       $cnt->{$xvals[-2]}++;
	  } else {
	       foreach my $i (1..$#xvals-1) {
		    if (($v >= $xvals[$i]) and ($v < $xvals[$i+1])) {
			 $cnt->{$xvals[$i]}++
		    }
	       }
	  }
     }

     my $total = sum map {$cnt->{$_}} keys %$cnt;
     my @cntx = ();
     foreach my $i (0..$#xvals-1) {
	  my $x0 = sprintf("%4.3f",$xvals[$i]);
	  my $x1 = sprintf("%4.3f",$xvals[$i+1]);
	  push(@cntx, [ [$x0,$x1], $cnt->{$xvals[$i]}/$total ]);
     }
     return @cntx;
}



sub writeFile {
     my ( $f, @data ) = @_;
     @data = () unless @data;
     open F, "> $f" or die "Can't open $f : $!";
     print F @data;
     close F;
}

sub readFileScalar  {
     my ( $f ) = @_;
     open F, "< $f" or die "Can't open $f : $!";
     my @f = <F>;		close F;
     return "@f";
}















# apply challenge to n-columns and get n-bit response
sub get_columns_response{
     my $spice_file = shift;
     my $instances = shift;
     my $c = shift;
        
     my @responses = ();
     foreach my $i (@$instances) {	       
	  push(@responses, get_column_response($spice_file,$i,$c));
     }
     return @responses;
}





# apply challenge to a single column and get its response bit
sub get_column_response{
     my $spice_file = shift;
     my $inst = shift;
     my $chal = shift;
        
     $Spice_Stats->{"NUM_RUNS"} += 1;

     system('rm -f ngspice.out');
     if (system('ngspice -b -o ngspice.out  '.$inst.' '.$chal.' '.$spice_file.'') != 0) {
	  print "FAILED SPICE RUN: $spice_file $inst $chal\n";
	  $Spice_Stats->{"NUM_FAILURES"} += 1;
	  carp("\n\nERROR: failed spice run");
	  return 0;
     }
     my $text = readFileScalar('ngspice.out');
     if ($text =~ /.*response\s+=\s+([\d\-\+e\.]+).*/gm) {
	  if (($1 > 0.3) and ($1 < 1.0)) {
	       $Spice_Stats->{"NUM_AMBIGIOUS_RESULTS"} += 1;
	       print "AMBIGIOUS SPICE RESULT: $spice_file $inst $chal\n";
	  }
	  my $response = ($1 > 0.65)? 1:0;
	  printf ("response = %+1.6f (%1i)\n", $1, $response);
	  return $response;
     } else {
	  croak;
     }
     return;
}






sub binary_entropy {
     my $pp = shift;
     my $qq = shift;
     return 0 if (($pp == 0) or ($qq==0));

     my $p = $pp/($pp+$qq);
     my $q = $qq/($pp+$qq);
     
     my $e = -1*$p*log2($p) - (1-$p)*log2(1-$p);
     return $e;
}


sub log2 {
     return log(shift)/log(2);
}


sub makeUnique {
     my @a = @_; 	
     my %saw;
     @a = grep(!$saw{$_}++, @a);   return @a;
}


sub sample { 
     my $in = shift; 
     my $n = shift; 
     my $x = dclone $in;
     my @y = shuffle(@$x); 
     carp print "can't sample $n from $#y\n" unless ($#y >= $n-1);
     @y = @y[0..$n-1]; 
     return @y; 
}


sub compute_hd {
     my $x1 = shift;
     my $x2 = shift;
     my $dist = 0;
     (@$x1 == @$x2) or croak;
     $dist = sum (map {$x1->[$_] xor $x2->[$_]} 0..$#$x1);
     return $dist;
}

sub unique_pairs {
     my $x = shift;
     my @out = ();
     my $max = $#$x;
     foreach my $i (0..$max) {
	  foreach my $j (($i+1)..$max) {
	       push(@out, [$x->[$i],$x->[$j]]);
	  }
     }
     return @out;
}

sub all_pairs {
     my $x = shift;
     my @out = ();
     my $max = $#$x;
     foreach my $i (0..$max) {
	  foreach my $j (0..$max) {
	       push(@out, [$x->[$i],$x->[$j]]);
	  }
     }
     return @out;
}


sub convert_spice_transient_output_to_dat {
     my $fname_spice_output = shift;
     my $fname_dat          = shift;

     my $d = parse_spice_output($fname_spice_output);
     open F, "> $fname_dat" or die "Can't open $fname_dat";
     foreach my $row (@$d) {
	  print F join(", ",@$row)."\n";
     }
     close F;
}


sub parse_spice_output {
     my $fname_in = shift;
     my $dat = ();
     open F, "< $fname_in" or die "Can't open";
     my @lines = <F>;
     close F;
     
     my $logging = 0;
     my $d = ();
     my $cols = ([], [], []);
     foreach my $line (@lines) {
	  if ($logging) {
	       if ($line =~ /^\d+\s+[\s\d\e\-\+\.]\s*/) {
		    my @vals = split(/\s+/,$line);
		    push (@$d, \@vals);
	       }
	  }
	  
	  if ($line =~ /^\s+Transient Analysis.*/) {
	       $logging = 1;
	  }
	  
     }
     return $d;
}





#
# create the spice deck for the challenge to set ic and word line
#
sub  create_challenge_spice {
     my ($args) = @_;
     my $challenge       = $args->{"CHALLENGE"};
     my $challenge_file  = $args->{"CHALLENGE_FILE"};
     my $num_cells       = $args->{"NUM_CELLS"};

     (@$challenge == $num_cells) or croak("bad challenge");;

     my $text .= "\n\n* challenge = ".join("",@$challenge)."\n\n";

     # first bit is the top cell, number 0
     foreach my $i (0..$#$challenge) {

	  my $c = $challenge->[$i];
	  $text .= "\n* bit $i = $c:\n";

	  if ($c == 3) {
	       $text .= "xwl$i wl$i wloff \n.ic v(xcell$i.a)=1.2\n";
	  } elsif ($c == 2) {
	       $text .= "xwl$i wl$i wloff \n.ic v(xcell$i.a)=0.0\n";
	  } elsif ($c == 1) {
	       $text .= "xwl$i wl$i wlon  \n.ic v(xcell$i.a)=1.2\n";
	  } elsif ($c == 0) {
	       $text .= "xwl$i wl$i wlon  \n.ic v(xcell$i.a)=0.0\n";
	  } else {
	       croak;
	  }

     }
     writeFile($challenge_file,$text);
     return;
}



1;
