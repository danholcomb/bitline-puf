#!/usr/bin/env perl

use Carp;
use strict;
use Data::Dumper;
$Data::Dumper::Terse = 1;
use Math::VecStat qw(max min maxabs minabs sum average);
use Getopt::Long;

require "spuf_utils.pl";

my $Fname_Challenges  = "challenges.data"; 
my $Num_Challenges    = 10; 
my $Fname_Instances   = "instances.data"; 
my $Num_Instances     = 1;
my $Spice_File        = "spuf4_ckt.sp";
my $Fname_Entropy     = "entropy.data";
my @zeros             = ();
my @ones              = ();
my $Num_Cells         = 16;

GetOptions ( 
	    "fname_instances=s"   => \$Fname_Instances,     
	    "num_instances=i"     => \$Num_Instances,     
	    "spice_file=s"        => \$Spice_File,
	    "fname_entropy=s"     => \$Fname_Entropy,
	    "zeros=i"             => \@zeros,
	    "ones=i"              => \@ones,
	    "num_cells=i"         => \$Num_Cells,
	   ); 

croak unless (@ones == @zeros);
my @zeros_ones = map{ [$zeros[$_],$ones[$_]] } (0..$#zeros);

measure_entropy_of_challenges({ 
			       "FNAME_INSTANCES"   => $Fname_Instances,
			       "NUM_INSTANCES"     => $Num_Instances,
			       "SPICE_FILE"        => $Spice_File,
			       "FNAME_ENTROPY"     => $Fname_Entropy,
			       "ZEROS_ONES"        => \@zeros_ones ,
			      });
exit(0);

sub measure_entropy_of_challenges {
     my ($args) = @_;

     my $fname_instances    = $args->{"FNAME_INSTANCES"};
     my $num_instances      = $args->{"NUM_INSTANCES"};
     my $spice_file         = $args->{"SPICE_FILE"};
     my $fname_entropy      = $args->{"FNAME_ENTROPY"};
     my @zeros_ones         = @{$args->{"ZEROS_ONES"}};

     print ("-"x80,"\n");
     print ("$0: measure_entropy_of_challenges\n");
     print ("args: \n ".Dumper($args)."\n");
     print ("-"x80,"\n");

     my $instances = eval(readFileScalar($fname_instances));

     my @results = ();
     foreach (@zeros_ones) {
     	  my $zeros = $_->[0];
     	  my $ones  = $_->[1];

     	  my @challenge = ();
     	  push(@challenge, 0) foreach (1..$zeros);
     	  push(@challenge, 1) foreach (1..$ones);
     	  push(@challenge, 2+int(rand(2))) foreach ($zeros+$ones .. $Num_Cells-1);
	  	  	  
	  print "TIME: measure_entropy_of_challenges: zeros=$zeros ones=$ones at ".localtime."\n";
	  
	  my $result = [$zeros,$ones,0,0]; #num zeros, num ones, num same resp, num diff resp 
	  foreach (1..$num_instances) {
	       
	       @challenge = shuffle(@challenge);
	       my $challenge_file = "challenge.sp";
	       create_challenge_spice({   "CHALLENGE"      => \@challenge,
					  "CHALLENGE_FILE" => $challenge_file,
					  "NUM_CELLS"      => $Num_Cells });
	       
	       print_spice_stats();
	       my $i1 = $instances->[int(rand($#$instances))];
	       my $i2 = $instances->[int(rand($#$instances))];

	       my $r1 = get_column_response($spice_file,$i1,$challenge_file);
	       my $r2 = get_column_response($spice_file,$i2,$challenge_file);
	       $result->[2+($r1 xor $r2)]++;
	  }
	  
	  push(@results,$result); 
     }
     print Dumper(@results);

     my $dat = create_dat(\@results);
     writeFile($fname_entropy,$dat);

}     

# create heat map data
sub create_dat {
     my $results = shift;
     
     print "\n\nRESULTS:\n".Dumper($results);

     my $dat = ();
     foreach (all_pairs([0..8])) {
	  my $zeros = $_->[0];
	  my $ones = $_->[1];
	  $dat->{$zeros}->{$ones} = -1;
     }

     
     foreach my $r (@$results) {
	  my $zeros = $r->[0];
	  my $ones = $r->[1];
	  my $diff = $r->[3];
	  $dat->{$zeros}->{$ones} = $diff;
     }
     print "\n\nDAT:\n".Dumper($dat);


     my $out = "";
     foreach my $zeros (0..8) {
	  foreach my $ones (0..8) {
	       $out .= sprintf ("%3i ",$dat->{$zeros}->{$ones});
	  }
	  $out .= "\n";
     }

     return $out;
}
