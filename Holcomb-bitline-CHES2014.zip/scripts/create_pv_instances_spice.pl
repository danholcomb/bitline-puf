#!/usr/bin/env perl

use Carp;
use strict;
use Data::Dumper;
$Data::Dumper::Terse = 1;
use Math::VecStat qw(max min maxabs minabs sum average);
use Getopt::Long;
use Math::Random::OO::Normal;

require "spuf_utils.pl";

my $Dir_Instances     = "instances"; 
my $Fname_Instances   = "instances/instances.data"; 
my $Num_Instances     = 2;
my $Seed              = time();
my $Fname_Pv_Data     = "";
my $Fname_Pv_Spice    = "";

GetOptions ( 
	    "dir_instances=s"    => \$Dir_Instances,
	    "fname_instances=s"  => \$Fname_Instances,
	    "num_instances=i"    => \$Num_Instances,     
	    "seed=i"             => \$Seed,
	    "fname_pv_data=s"    => \$Fname_Pv_Data,
	    "fname_pv_spice=s"   => \$Fname_Pv_Spice,
	   ); 

print ("-"x80,"\n");
printf ("dir_instances       = %s \n",$Dir_Instances);
printf ("fname_instances     = %s \n",$Fname_Instances);
printf ("num_instances       = %s \n",$Num_Instances);
printf ("seed                = %s \n",$Seed);
printf ("fname_pv_data       = %s \n",$Fname_Pv_Data);
printf ("fname_pv_spice      = %s \n",$Fname_Pv_Spice);
my $pv = eval(readFileScalar($Fname_Pv_Data));
print Dumper($pv);
print ("-"x80,"\n");


my %RV;    #random variables
foreach my $k (keys %$pv) {
     $RV{$k} =  Math::Random::OO::Normal->new(  $pv->{$k}->[0], $pv->{$k}->[1]   );     
}
$RV{$_}->seed($Seed++) foreach(keys %RV);


system("rm -rf $Dir_Instances");
system("mkdir $Dir_Instances");

my @instances = ();
foreach my $i (0..$Num_Instances-1) {
     my $fname = $Dir_Instances."/inst".$i.".sp";
     create_instance_spice({   "FNAME_OUT"      => $fname,
			       "FNAME_PV_SPICE" => $Fname_Pv_Spice   });
     push(@instances,$fname);
}
writeFile($Fname_Instances,Dumper(\@instances));
exit(0);


sub  create_instance_spice {
     my ($args) = @_;
     my $fname_out        = $args->{"FNAME_OUT"};
     my $fname_pv_spice   = $args->{"FNAME_PV_SPICE"};
     my $text = "";

     my @lines = split("\n",readFileScalar($fname_pv_spice));

     foreach my $line (@lines) {
	  if ($line =~ /(\.param [\w_]+ = )[\-\+\d\.e]+\s+;([\w_]+)\s*$/) {
	       my $param_text = $1;
	       my $param_name = $2;
	       croak ("PV variable not understood") unless defined ($RV{$param_name});
	       my $param_val =  $RV{$param_name}->next();
	       my $param_lower_bound = $pv->{$param_name}->[2];
	       $param_val =  ($param_val>$param_lower_bound) ? $param_val : $param_lower_bound;
	       $line = $param_text." ".$param_val;
	  } elsif( $line =~ /^\s*$/) {
	       ;
	  } else {
	       croak("cant parse pv line ->$line<-\n");
	  }
	  
     }

     my $text = join("\n",@lines);
     writeFile($fname_out,$text);
     return;
}
