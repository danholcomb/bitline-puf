#!/usr/bin/env perl

use Carp;
use strict;
use Data::Dumper;
$Data::Dumper::Terse = 1;
use Math::VecStat qw(max min maxabs minabs sum average);
use Getopt::Long;

require "spuf_utils.pl";


my $Dir_Challenges    = "dir_exp_challenges"; #the file with hd values in list
my $Fname_Challenges  = "exp.challenges"; 
my $Num_Challenges    = 1;
my $Num_Cells         = 4;
my $W_Min             = 0;
my $W_Max             = 1;
my $N_Min             = 0; 
my $N_Max             = 100; # the max number of cells to be used as 0 or 1
my $Seed              = time();
GetOptions ( 
	    "num_cells=i"         => \$Num_Cells,     
	    "num_challenges=i"    => \$Num_Challenges,
	    "dir_challenges=s"    => \$Dir_Challenges,
	    "fname_challenges=s"  => \$Fname_Challenges,
	    "w_min=f"             => \$W_Min,
	    "w_max=f"             => \$W_Max,
	    "n_min=i"             => \$N_Min,
	    "n_max=i"             => \$N_Max,
	    "seed=i"              => \$Seed,
	   ); 

srand($Seed);

create_challenges_spice({   "NUM_CHALLENGES"   => $Num_Challenges,
			    "NUM_CELLS"        => $Num_Cells,
			    "DIR_CHALLENGES"   => $Dir_Challenges,			       
			    "FNAME_CHALLENGES" => $Fname_Challenges,
			    "W_MIN"            => $W_Min, 
			    "W_MAX"            => $W_Max,      
			    "N_MIN"            => $N_Min, 
			    "N_MAX"            => $N_Max   });


sub  create_challenges_spice {
     my ($args) = @_;
     my $dir              = $args->{"DIR_CHALLENGES"};
     my $fname_challenges = $args->{"FNAME_CHALLENGES"};
     my $num_challenges   = $args->{"NUM_CHALLENGES"};
     my $num_cells        = $args->{"NUM_CELLS"};
     my $w_min            = $args->{"W_MIN"};
     my $w_max            = $args->{"W_MAX"};
     my $n_min            = $args->{"N_MIN"};
     my $n_max            = $args->{"N_MAX"};

     print ("-"x80,"\n");
     print ("$0: \n args: \n ".Dumper($args)."\n");
     print ("-"x80,"\n");

     system("rm -rf $dir");
     system("mkdir $dir");
     my @challenges = ();

     croak if ($num_challenges > (4 ** $num_cells));

     my $i = 0;
     while ($#challenges < $num_challenges-1) {
	  last if ($i++ > 1000000);
	  my @challenge = map {int(rand(4))} (0..$num_cells-1);

	  my @zeros = grep {$_ == 0} @challenge;
	  my @ones  = grep {$_ == 1} @challenge;

	  while ((@ones + @zeros) > $n_max) {
	       $challenge[0] = 2+int(rand(2));
	       @challenge = shuffle(@challenge);
	       @zeros = grep {$_ == 0} @challenge;
	       @ones  = grep {$_ == 1} @challenge;
	  }

	  my $n = @ones + @zeros;
	  my $w = ((@zeros == 0) or (@ones==0))? 0 : @ones/$n;

	  if (($w >= $w_min) and ($w <= $w_max) and ($n >= $n_min) and ($n <= $n_max)) {
	       my $challenge_file = $dir."/c".join("",@challenge).".sp";
	       create_challenge_spice({   "CHALLENGE"      => \@challenge,
					  "CHALLENGE_FILE" => $challenge_file,
					  "NUM_CELLS"      => $num_cells });
	       push(@challenges,$challenge_file);
	       @challenges = makeUnique(@challenges);
	  }
     }
     print Dumper(\@challenges);
     writeFile($fname_challenges,Dumper(\@challenges));
     return;
}





