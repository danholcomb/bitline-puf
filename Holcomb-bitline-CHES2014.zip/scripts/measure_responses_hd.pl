#!/usr/bin/env perl

use Carp;
use strict;
use Data::Dumper;
$Data::Dumper::Terse = 1;
use Math::VecStat qw(max min maxabs minabs sum average);
use Getopt::Long;

require "spuf_utils.pl";


my $Fname_Challenges  = "challenges.data"; 
my $Spice_File        = "";
my $Fname_Instances   = "instances.data"; 
my $Num_Pufs          = 2;	
my $Num_Challenges    = 1;	
my $Num_Columns       = 4;	
my $Num_Repeats       = 2;	
my $Fname_Data        = "foo";

GetOptions ( 
	    "fname_challenges=s"  => \$Fname_Challenges,
	    "fname_instances=s"   => \$Fname_Instances,     
	    "spice_file=s"        => \$Spice_File,
	    "num_challenges=i"    => \$Num_Challenges,
	    "num_pufs=i"          => \$Num_Pufs,     
	    "num_columns=i"       => \$Num_Columns,
	    "num_repeats=i"       => \$Num_Repeats,
	    "fname_responses=s"   => \$Fname_Data,
	   ); 


measure_hd_responses({ 
		      "FNAME_CHALLENGES"  => $Fname_Challenges,
		      "SPICE_FILE"        => $Spice_File,
		      "FNAME_INSTANCES"   => $Fname_Instances,
		      "NUM_PUFS"          => $Num_Pufs,
		      "NUM_CHALLENGES"    => $Num_Challenges,   
		      "NUM_COLUMNS"       => $Num_Columns,   
		      "NUM_REPEATS"       => $Num_Repeats,
		      "FNAME_DATA"        => $Fname_Data  
		     });



sub measure_hd_responses {
     my ($args) = @_;
     my $fname_challenges    = $args->{"FNAME_CHALLENGES"};
     my $fname_instances     = $args->{"FNAME_INSTANCES"}; 
     my $spice_file          = $args->{"SPICE_FILE"};
     my $fname_data          = $args->{"FNAME_DATA"};
     my $num_pufs            = $args->{"NUM_PUFS"};
     my $num_challenges      = $args->{"NUM_CHALLENGES"}; 
     my $num_columns         = $args->{"NUM_COLUMNS"};
     my $num_repeats         = $args->{"NUM_REPEATS"}; 

     print ("-"x80,"\n");
     print ("$0: measure_hamming_distances\n");
     print ("args: \n ".Dumper($args)."\n");
     print ("-"x80,"\n");
     
     
     my $c1 = eval(readFileScalar($fname_challenges));
     my $i1 = eval(readFileScalar($fname_instances));
 
     my $dat = ();
     foreach my $idx_challenge (0..$num_challenges-1) {
     	  my $chal = $c1->[int(rand($#$c1))];
     	  print "TIME: measure_hds: starting challenge ".($idx_challenge+1)."/".$num_challenges." at ".localtime."\n";
	  print_spice_stats();
	  foreach my $idx_instance (0..$num_pufs-1) {
	       my @instances  = sample($i1, $num_columns); 	  # the columns for this PUF
	       foreach (0..$num_repeats-1) {
		    my @resp = get_columns_response($spice_file,\@instances,$chal);
		    push(@{$dat->[$idx_challenge]->[$idx_instance]}, \@resp);
	       }
	  }
	  writeFile($fname_data, Dumper($dat));
     }

     print_spice_stats();
     writeFile($fname_data, Dumper($dat));
     return;
     
}









