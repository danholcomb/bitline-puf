#!/usr/bin/env perl

use strict;
use Getopt::Long;

use Carp;

use Data::Dumper;
$Data::Dumper::Terse = 1;
use Math::VecStat qw(max min maxabs minabs sum average);

require "spuf_utils.pl";

my $Fname_Responses  = ""; 
my $Fname_Dat        = ""; 
my $Exp_Iterations   = 10; 

my $Num_Stages = 16;


GetOptions ( 
	    "fname_responses=s"  => \$Fname_Responses,
	    "exp_iterations=i"   => \$Exp_Iterations,
	    "fname_dat=s"        => \$Fname_Dat,
	   ); 


my @challenges = ();
my @responses = ();

print "Fname_Responses = $Fname_Responses\n";

my $data = eval(readFileScalar($Fname_Responses));
print "read data ok";


my $D = ();
foreach (@$data) {
     my $idx_instance  = $_->[0];
     my $instance      = $_->[1];
     my $challenge     = $_->[2];
     my $response      = $_->[3];
     
     $challenge =~ s/[^\d]//g;
     $response = 2*$response -1;
     push (@{$D->[$idx_instance]->{CHALLENGES}}, $challenge);
     push (@{$D->[$idx_instance]->{RESPONSES}}, $response);
}

foreach my $idx_instance (0..$#$D) {
     my $crps_instance = $D->[$idx_instance];
     my @challenges = @{$crps_instance->{"CHALLENGES"}};
     my @responses = @{$crps_instance->{"RESPONSES"}};


     print "instance: $idx_instance responses: ".average(map {($_ + 1) /2} @responses)."\n";
     my @Accuracy_Scores = ();
     my @Num_Trainings = ();

     # do a bunch of random iterations each experiment chooses a threshold
     # to determine the size of training vs test, then partitions data and
     # runs SVM
     foreach (1..$Exp_Iterations) {

	  open (TRAINING, ">trainPUF.dat") or die "Can't open training file";
	  open (TEST, ">testPUF.dat") or die "Can't open training file";

	  my $threshold = rand(0.5); #training is no more than half of all points
	  my $num_training = 1;
	  foreach my $i (0..$#challenges) {

	       my @challenge_bits = split (/\s*/,$challenges[$i]);
	       my $response = $responses[$i]; 

	       (@challenge_bits == $Num_Stages) or die;
	       my $f = getFeaturesBitlinePuf(@challenge_bits);

	       my $inner_rand = rand(1.0);
	       if ($inner_rand < $threshold) {
		    print TRAINING "$response $f\n";
		    $num_training++;
	       } else {
		    print TEST "$response $f\n";
	       }
	  }

	  close TRAINING;
	  close TEST;

	  # I don't know what settings are appropriate for the SVM classifier

	  # -t 0 is linear	
	  # 1 is polynomial
	  system("svm_learn -v 0 -t 0 -z c -a alphas.txt trainPUF.dat pufModel");
	  system("svm_classify testPUF.dat pufModel predictions > dumpResults");

	  my $accuracy = readSVMDumpResults("dumpResults");
	  print "$num_training $accuracy \n";
	  push (@Num_Trainings,$num_training);
	  push (@Accuracy_Scores,$accuracy);
     }

     open (PLOT, ">$Fname_Dat".$idx_instance) or die; 
     for my $i (0..$#Num_Trainings) {
	  printf PLOT ("%2i, %6i, %4.6f, \n",$i,$Num_Trainings[$i],$Accuracy_Scores[$i]);
     }
     close PLOT;

     


}

exit(0);


sub readSVMDumpResults {
     my $fname = shift;
     open F, "< $fname" or die; # "Can't open $f : $!";
     my @f = <F>;
     close F;
     my $d = "@f";

     my $accuracy = -1;		#in case we dont find it
     if ($d =~ /.*Accuracy on test set: (.*)%.*/ ) {
	  $accuracy = $1;
     }
     return $accuracy;
}


# map 0/1/2/3 to 0:[0/1] 1:[0/1] 2:[0/1] 3:[0/1] for each of the features
sub getFeaturesBitlinePuf{
     my @c = @_;	
     
     my $s = "";
     foreach my $i (0..$#c) {
	  my @is_one = (0,0,0,0);
	  $is_one[$c[$i]] = 1;
	  $s .= sprintf ("%4i:%-4i ",1+4*$i+$_,$is_one[$_]) foreach (0..$#is_one);
     }
     return $s;
}
