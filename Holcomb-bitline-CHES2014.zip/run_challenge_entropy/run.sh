
cp ../transistors_as_subckts.sp .
cp ../bitline_puf_16x1_ckt.sp .
cp ../bitline_puf_16x1_pv.sp .
cp ../bitline_puf_16x1_pv.data .


create_pv_instances_spice.pl \
     --dir_instances    instances \
     --fname_instances  instances/instances.data \
     --num_instances    10000 \
     --fname_pv_data    bitline_puf_16x1_pv.data \
     --fname_pv_spice   bitline_puf_16x1_pv.sp \


measure_entropy_of_challenges.pl \
    --spice_file        bitline_puf_16x1_ckt.sp \
    --fname_instances   instances/instances.data \
    --num_instances     1000 \
    --fname_entropy     "challenge_entropy.dat" \
    --num_cells         16 \
    --ones 1 --zeros 1 \
    --ones 1 --zeros 2 \
    --ones 1 --zeros 3 \
    --ones 1 --zeros 4 \
    --ones 1 --zeros 5 \
    --ones 1 --zeros 6 \
    --ones 1 --zeros 7 \
    --ones 1 --zeros 8 \
    --ones 2 --zeros 1 \
    --ones 2 --zeros 2 \
    --ones 2 --zeros 3 \
    --ones 2 --zeros 4 \
    --ones 2 --zeros 5 \
    --ones 2 --zeros 6 \
    --ones 2 --zeros 7 \
    --ones 2 --zeros 8 \
    --ones 3 --zeros 1 \
    --ones 3 --zeros 2 \
    --ones 3 --zeros 3 \
    --ones 3 --zeros 4 \
    --ones 3 --zeros 5 \
    --ones 3 --zeros 6 \
    --ones 3 --zeros 7 \
    --ones 3 --zeros 8 \
    --ones 4 --zeros 1 \
    --ones 4 --zeros 2 \
    --ones 4 --zeros 3 \
    --ones 4 --zeros 4 \
    --ones 4 --zeros 5 \
    --ones 4 --zeros 6 \
    --ones 4 --zeros 7 \
    --ones 4 --zeros 8 \
    --ones 5 --zeros 1 \
    --ones 5 --zeros 2 \
    --ones 5 --zeros 3 \
    --ones 5 --zeros 4 \
    --ones 5 --zeros 5 \
    --ones 5 --zeros 6 \
    --ones 5 --zeros 7 \
    --ones 5 --zeros 8 \
    --ones 6 --zeros 1 \
    --ones 6 --zeros 2 \
    --ones 6 --zeros 3 \
    --ones 6 --zeros 4 \
    --ones 6 --zeros 5 \
    --ones 6 --zeros 6 \
    --ones 6 --zeros 7 \
    --ones 6 --zeros 8 \
    --ones 7 --zeros 1 \
    --ones 7 --zeros 2 \
    --ones 7 --zeros 3 \
    --ones 7 --zeros 4 \
    --ones 7 --zeros 5 \
    --ones 7 --zeros 6 \
    --ones 7 --zeros 7 \
    --ones 7 --zeros 8 \
    --ones 8 --zeros 1 \
    --ones 8 --zeros 2 \
    --ones 8 --zeros 3 \
    --ones 8 --zeros 4 \
    --ones 8 --zeros 5 \
    --ones 8 --zeros 6 \
    --ones 8 --zeros 7 \
    --ones 8 --zeros 8 \


replicate_heatmap_data.pl challenge_entropy.dat 10
gnuplot challenge_entropy.gp
epstopdf challenge_entropy.eps
rm challenge_entropy.eps
